#!/usr/bin/env python3
"""KUANSANTI Smart Café: dependency-free server, SQLite, same-origin customer/owner APIs.
Run: python server.py --host 0.0.0.0 --port 8000
For real-world deployment, put behind HTTPS and replace demo credentials.
"""
import os, sys, json, sqlite3, time, math, re, hmac, hashlib, secrets, argparse, threading, socket, io
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from urllib.request import urlopen, Request
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

ROOT=Path(__file__).resolve().parent
DB=ROOT/'data'/'cafe.sqlite3'
TZ=ZoneInfo('Asia/Bangkok')
OWNER_PIN=os.environ.get('OWNER_PIN','2468')
SESSION_SECRET=os.environ.get('SESSION_SECRET') or secrets.token_hex(32)
DEMO_DATA=os.environ.get('DEMO_DATA','1')!='0'
LOCK=threading.RLock()
WEATHER_CACHE={'at':0,'value':None}
GOOD_SOURCES={'counter','inspection','road','community','social'}
GOOD_MOODS={'refresh','focus','relax','happy','any'}

def now(): return datetime.now(TZ)
def stamp(): return now().isoformat(timespec='seconds')
def datekey(v): return str(v or '')[:10]
def conn():
 c=sqlite3.connect(DB,timeout=15,check_same_thread=False)
 c.row_factory=sqlite3.Row
 return c

def init_db():
 DB.parent.mkdir(exist_ok=True)
 with LOCK, conn() as c:
  c.executescript('''
   CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY, data TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS inventory(id TEXT PRIMARY KEY, data TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS settings(id TEXT PRIMARY KEY, data TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY, created TEXT, status TEXT, paid INTEGER, total INTEGER, cost INTEGER, discount INTEGER, source TEXT, mood TEXT, weather TEXT, customer TEXT, phone TEXT, notes TEXT, items TEXT);
   CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT, kind TEXT, source TEXT, product TEXT, mood TEXT);
   ''')
  count=c.execute('SELECT COUNT(*) FROM products').fetchone()[0]
  if not count:
   seed=json.loads((ROOT/'data'/'seed.json').read_text(encoding='utf-8'))
   for p in seed['products']: c.execute('INSERT INTO products VALUES (?,?)',(p['id'],json.dumps(p,ensure_ascii=False)))
   for inv in seed['inventory']: c.execute('INSERT INTO inventory VALUES (?,?)',(inv['id'],json.dumps(inv,ensure_ascii=False)))
   c.execute('INSERT INTO settings VALUES (?,?)',('main',json.dumps(seed['settings'],ensure_ascii=False)))
   if DEMO_DATA:
    demo=[('09:04','americano','counter',2,1),('09:20','latte','inspection',1,1),('09:43','croissant','inspection',1,1),('10:04','orange','road',1,1),('10:22','thai_tea','inspection',2,1),('10:38','latte','community',2,1),('11:02','brownie','counter',1,1),('11:17','americano','inspection',2,1),('11:40','cocoa','community',1,1),('12:12','caramel','road',1,1),('12:34','toast','community',1,1),('13:10','matcha','social',1,1),('14:05','orange','inspection',2,1)]
    lookup={p['id']:p for p in seed['products']}
    for i,(hm,pid,source,qty,paid) in enumerate(demo):
     p=lookup[pid]; d=now().date().isoformat()+'T'+hm+':00+07:00'
     item={'id':pid,'name':p['name'],'qty':qty,'price':p['price'],'cost':p['cost'],'sweet':50,'ice':'normal','notes':''}
     c.execute('INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(f'DEMO-{i+1:03d}',d,'completed',paid,p['price']*qty,p['cost']*qty,0,source,'any','sunny','','','ตัวอย่างข้อมูลจำลอง',json.dumps([item],ensure_ascii=False)))
    for j in range(18):
     d=now().date().isoformat()+f'T{9+j//3:02d}:{(j%3)*18:02d}:00+07:00'
     c.execute('INSERT INTO events(created,kind,source,product,mood) VALUES (?,?,?,?,?)',(d,'view',['inspection','counter','road','community'][j%4],['latte','orange','americano'][j%3],['relax','refresh','focus'][j%3]))

def fetch_data(c):
 products=[json.loads(r[0]) for r in c.execute('SELECT data FROM products')]
 inventory=[json.loads(r[0]) for r in c.execute('SELECT data FROM inventory')]
 settings=json.loads(c.execute("SELECT data FROM settings WHERE id='main'").fetchone()[0])
 return products,inventory,settings

def live_weather():
 if time.time()-WEATHER_CACHE['at']<1200: return WEATHER_CACHE['value']
 value=None
 try:
  url='https://api.open-meteo.com/v1/forecast?latitude=7.0084&longitude=100.4747&current=temperature_2m,precipitation,weather_code&timezone=Asia%2FBangkok'
  req=Request(url,headers={'User-Agent':'KuansantiSmartCafeDemo/1.0'})
  with urlopen(req,timeout=3) as response: d=json.load(response)['current']
  code=int(d.get('weather_code',0)); rain=float(d.get('precipitation',0))
  weather='rainy' if rain>0 or code>=51 else 'sunny' if float(d.get('temperature_2m',28))>=30 else 'normal'
  value={'weather':weather,'temperature':d.get('temperature_2m'),'rain_mm':rain,'source':'open-meteo','updated':stamp()}
 except Exception:
  value=None
 WEATHER_CACHE.update({'at':time.time(),'value':value})
 return value

def context(settings):
 if settings.get('weather_mode')=='live':
  found=live_weather()
  if found: return found
  return {'weather':settings.get('weather','normal'),'source':'demo-fallback','updated':stamp()}
 return {'weather':settings.get('weather','normal'),'source':'demo','updated':stamp()}

def available(p, stocks):
 if not p.get('active',True): return 0
 recipe=p.get('recipe',{})
 if not recipe: return 9999
 return min([int(stocks.get(k,0)//v) for k,v in recipe.items() if v>0] or [9999])

def public_data():
 with conn() as c: products,inv,settings=fetch_data(c)
 stocks={i['id']:i['qty'] for i in inv}
 safe={k:settings.get(k) for k in ('shop_name','open','weather','weather_mode','promotion_on','bundle_discount','ai_on','note','service_mode')}
 public_products=[]
 for p in products:
  # Do not expose current product costs, bills of materials or supplier usage to customers.
  safe_product={k:p[k] for k in ('id','name','en','category','price','emoji','moods','tags','description','prep','popular','color') if k in p}
  safe_product['available']=max(0,available(p,stocks))
  safe_product['active']=p.get('active',True)
  safe_product['priority']=round(p.get('popular',5)*.6+(p['price']-p['cost'])*.035,2)
  public_products.append(safe_product)
 return {'products':public_products,'settings':safe,'context':context(settings),'server_time':stamp(),'demo_data':DEMO_DATA}

def order_dict(r):
 d=dict(r)
 d['paid']=bool(d['paid'])
 d['items']=json.loads(d['items'])
 return d

def make_brief(products,inventory,orders,settings,ctx):
 sales=[o for o in orders if o['paid'] and o['status']!='cancelled' and datekey(o['created'])==now().date().isoformat()]
 drinks=sum(i['qty'] for o in sales for i in o['items'] if any(p['id']==i['id'] and p['category']!='bakery' for p in products))
 source_sales={}
 for o in sales: source_sales[o['source']]=source_sales.get(o['source'],0)+o['total']
 top_source=max(source_sales,key=source_sales.get) if source_sales else 'inspection'
 low=[i for i in inventory if i['qty']<=i['minimum']]
 exp= [p for p in products if p.get('active',True) and p['category']!='bakery']
 hero=max(exp,key=lambda p:(p['price']-p['cost'])*(.3+p.get('popular',5)/10)) if exp else None
 wm=ctx['weather']
 if wm=='rainy':
  season='ช่วงฝน'; action='ทดลองนำเมนูร้อน/ละมุนขึ้นก่อนใน QR และอย่าเพิ่งเตรียมน้ำแข็งเกินยอดจริง'; audience='ลูกค้า ตรอ. และคนทำงานใกล้ร้าน'
 elif wm=='sunny':
  season='อากาศร้อน/แดด'; action='ทดลองนำเมนูเย็นสดชื่นขึ้นก่อนใน QR และเตรียมน้ำแข็งแบบเติมรอบ'; audience='ลูกค้า ตรอ. และคนผ่านหน้าร้าน'
 else:
  season='อากาศทั่วไป'; action='แสดงเมนูยอดนิยมและคอมโบเครื่องดื่ม + ขนม โดยวัดยอดสั่งจริง'; audience='ลูกค้าประจำ + ลูกค้า ตรอ.'
 cards=[
  {'type':'today','title':'กลยุทธ์วันนี้: '+season,'audience':audience,'action':action,'basis':'อิงบริบทอากาศ ('+ctx['source']+') และกลุ่มลูกค้าใกล้ร้าน','confidence':'ทดลองก่อนสรุปผล'},
  {'type':'tomorrow','title':'แผนเตรียมพรุ่งนี้','audience':'พนักงานชงและผู้จัดการ','action':('วันนี้ขายเครื่องดื่มแล้ว '+str(drinks)+' แก้ว ลองใช้เป็นค่าฐานขั้นต่ำสำหรับประเมินวัตถุดิบพรุ่งนี้' if drinks else 'ยังมีข้อมูลขายน้อย ให้เตรียมขั้นต่ำและเติมสต๊อกตามยอดจริง')+' พร้อมเช็กวัตถุดิบเสียง่ายก่อนปิดร้าน','basis':'ยอดชำระเงินวันนี้ (ยังไม่ใช่พยากรณ์ ML)','confidence':'ประมาณการเบื้องต้น'},
  {'type':'inventory','title':'ป้องกันต้นทุนจมและสินค้าขาด','audience':'เจ้าของร้าน','action':(('วัตถุดิบต่ำกว่าจุดเตือน: '+', '.join(x['name'] for x in low[:4])) if low else 'สต๊อกยังไม่ต่ำกว่าจุดเตือน ตรวจของเสียง่ายและสั่งเติมเฉพาะที่จำเป็น'),'basis':'สต๊อกและจุดเตือนที่บันทึกไว้','confidence':'ข้อมูลภายในร้าน'},
  {'type':'customer','title':'กลุ่มลูกค้าควรให้ความสำคัญ','audience':'กลุ่มลูกค้า '+({'inspection':'ตรอ.','counter':'หน้าร้าน','road':'ริมถนน','community':'ชุมชน','social':'ออนไลน์'}.get(top_source,top_source)),'action':'วัดว่าแหล่ง QR ใดนำไปสู่ยอดชำระเงินจริง แล้วจัดสรรป้าย/โปรให้กลุ่มที่ทำกำไรเพิ่มสุทธิดีกว่า','basis':'ยอดขายแยกแหล่งสแกน QR และต้นทุนโปร','confidence':'ระวังขนาดตัวอย่างเล็ก'}
 ]
 return cards

def owner_snapshot():
 with conn() as c:
  products,inventory,settings=fetch_data(c)
  rows=c.execute('SELECT * FROM orders ORDER BY created DESC LIMIT 200').fetchall()
  orders=[order_dict(r) for r in rows]
  ev=[dict(x) for x in c.execute('SELECT created,kind,source,product,mood FROM events ORDER BY id DESC LIMIT 1500')]
 ctx=context(settings)
 paid=[o for o in orders if o['paid'] and o['status']!='cancelled' and datekey(o['created'])==now().date().isoformat()]
 recent=[o for o in orders if datekey(o['created'])==now().date().isoformat() and o['status']!='cancelled']
 prodmap={p['id']:p for p in products}
 total=sum(o['total'] for o in paid)
 cost=sum(o['cost'] for o in paid)
 drinks=sum(it['qty'] for o in paid for it in o['items'] if prodmap.get(it['id'],{}).get('category')!='bakery')
 bakery=sum(it['qty'] for o in paid for it in o['items'] if prodmap.get(it['id'],{}).get('category')=='bakery')
 return {'products':products,'inventory':inventory,'settings':settings,'orders':orders,'events':ev,'context':ctx,'briefs':make_brief(products,inventory,orders,settings,ctx),'summary':{'revenue':total,'cost':cost,'margin':total-cost,'orders':len(recent),'paid_orders':len(paid),'cups':drinks,'bakery':bakery,'low_stock':sum(x['qty']<=x['minimum'] for x in inventory)},'demo_data':DEMO_DATA}

def clean_text(v,n): return str(v or '').strip()[:n]
def safe_source(v): return v if v in GOOD_SOURCES else 'counter'
def create_order(data):
 raw=data.get('items',[])
 if not isinstance(raw,list) or not 1<=len(raw)<=30: raise ValueError('กรุณาเพิ่มสินค้าในตะกร้า')
 with LOCK,conn() as c:
  c.execute('BEGIN IMMEDIATE')
  ps, inv, settings=fetch_data(c)
  if not settings.get('open',True): raise ValueError('ร้านปิดรับออเดอร์ชั่วคราว')
  pmap={p['id']:p for p in ps}
  stocks={i['id']:i for i in inv}
  items=[]; needs={}; subtotal=0; cost=0; nbev=0; nbak=0
  for it in raw:
   if not isinstance(it,dict) or it.get('id') not in pmap: raise ValueError('พบสินค้าที่ไม่ถูกต้อง')
   p=pmap[it['id']]
   if not p.get('active',True): raise ValueError('เมนูนี้หยุดขายชั่วคราว: '+p['name'])
   qty=it.get('qty',1)
   if type(qty)!=int or qty<1 or qty>20: raise ValueError('จำนวนสินค้าต้องอยู่ระหว่าง 1–20')
   sweet=it.get('sweet',50)
   if sweet not in (0,25,50,75,100): sweet=50
   ice=it.get('ice','normal')
   if ice not in ('normal','less','none'): ice='normal'
   row={'id':p['id'],'name':p['name'],'qty':qty,'price':p['price'],'cost':p['cost'],'sweet':sweet,'ice':ice,'notes':clean_text(it.get('notes'),100)}
   items.append(row);subtotal+=p['price']*qty;cost+=p['cost']*qty
   if p['category']=='bakery':nbak+=qty
   else:nbev+=qty
   for key,amount in p.get('recipe',{}).items(): needs[key]=needs.get(key,0)+amount*qty
  if sum(i['qty'] for i in items)>50: raise ValueError('จำนวนสินค้าต่อบิลมากเกินไป')
  for key,n in needs.items():
   if key not in stocks or stocks[key]['qty']<n: raise ValueError('วัตถุดิบไม่เพียงพอ: '+(stocks.get(key,{}).get('name') or key))
  for key,n in needs.items():
   stocks[key]['qty']-=n
   c.execute('UPDATE inventory SET data=? WHERE id=?',(json.dumps(stocks[key],ensure_ascii=False),key))
  promo= int(settings.get('bundle_discount',0)) if settings.get('promotion_on',True) else 0
  promo=max(0,min(promo,20))
  discount=min(nbev,nbak)*promo
  discount=min(discount,subtotal)
  orderid='KS'+now().strftime('%m%d')+'-'+secrets.token_hex(3).upper()
  source=safe_source(data.get('source'))
  mood=data.get('mood','any')
  if mood not in GOOD_MOODS:mood='any'
  weather=context(settings)['weather']
  customer=clean_text(data.get('customer'),70)
  phone=clean_text(data.get('phone'),20)
  if phone and not re.fullmatch(r'[0-9+\- ]{8,20}',phone): raise ValueError('รูปแบบเบอร์โทรไม่ถูกต้อง')
  notes=clean_text(data.get('notes'),220)
  c.execute('INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(orderid,stamp(),'new',0,subtotal-discount,cost,discount,source,mood,weather,customer,phone,notes,json.dumps(items,ensure_ascii=False)))
 return {'id':orderid,'total':subtotal-discount,'discount':discount,'status':'new','message':'รับออเดอร์แล้ว กรุณาชำระเงินที่เคาน์เตอร์'}

def update_order(data):
 oid=clean_text(data.get('id'),45)
 with LOCK,conn() as c:
  r=c.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
  if not r: raise ValueError('ไม่พบออเดอร์')
  if 'paid' in data:
   if r['status']=='cancelled': raise ValueError('ออเดอร์ถูกยกเลิก')
   c.execute('UPDATE orders SET paid=? WHERE id=?',(1 if data['paid'] else 0,oid))
  if 'status' in data:
   status=data['status']
   if status not in ('new','preparing','ready','completed','cancelled'): raise ValueError('สถานะไม่ถูกต้อง')
   if r['status']=='cancelled' and status!='cancelled': raise ValueError('ไม่สามารถเปิดออเดอร์ที่ยกเลิกแล้ว')
   if status=='cancelled' and r['status']!='cancelled':
    if r['paid']: raise ValueError('ต้องจัดการคืนเงินและยกเลิกสถานะชำระก่อน')
    products,inv,_=fetch_data(c)
    stocks={x['id']:x for x in inv}; pmap={p['id']:p for p in products}
    for i in json.loads(r['items']):
     for key,amount in pmap.get(i['id'],{}).get('recipe',{}).items():
      if key in stocks: stocks[key]['qty']+=amount*i['qty']
    for x in stocks.values():c.execute('UPDATE inventory SET data=? WHERE id=?',(json.dumps(x,ensure_ascii=False),x['id']))
   c.execute('UPDATE orders SET status=? WHERE id=?',(status,oid))
 return {'ok':True}

def update_stock(d):
 iid=clean_text(d.get('id'),50)
 with LOCK,conn() as c:
  r=c.execute('SELECT data FROM inventory WHERE id=?',(iid,)).fetchone()
  if not r:raise ValueError('ไม่พบวัตถุดิบ')
  it=json.loads(r[0]);qty=d.get('qty')
  if type(qty) not in (int,float) or qty<0 or qty>1000000:raise ValueError('จำนวนสต๊อกไม่ถูกต้อง')
  it['qty']=round(qty,2)
  c.execute('UPDATE inventory SET data=? WHERE id=?',(json.dumps(it,ensure_ascii=False),iid))
 return {'ok':True}

def update_product(d):
 pid=clean_text(d.get('id'),50)
 with LOCK,conn() as c:
  r=c.execute('SELECT data FROM products WHERE id=?',(pid,)).fetchone()
  if not r:raise ValueError('ไม่พบเมนู')
  p=json.loads(r[0]);
  for key in ('price','cost'):
   if key in d:
    v=d[key]
    if type(v)!=int or v<0 or v>10000:raise ValueError('ราคาและต้นทุนต้องเป็นจำนวนเต็ม 0–10000')
    p[key]=v
  if 'active' in d:p['active']=bool(d['active'])
  c.execute('UPDATE products SET data=? WHERE id=?',(json.dumps(p,ensure_ascii=False),pid))
 return {'ok':True}

def update_settings(d):
 allowed={'open':bool,'ai_on':bool,'promotion_on':bool,'weather':str,'weather_mode':str,'bundle_discount':int,'note':str,'shop_name':str}
 with LOCK,conn() as c:
  s=json.loads(c.execute("SELECT data FROM settings WHERE id='main'").fetchone()[0])
  for k,t in allowed.items():
   if k not in d:continue
   v=d[k]
   if type(v)!=t:raise ValueError('ข้อมูลตั้งค่าไม่ถูกต้อง: '+k)
   if k=='weather' and v not in ('sunny','rainy','normal'):raise ValueError('สถานการณ์ไม่ถูกต้อง')
   if k=='weather_mode' and v not in ('demo','live'):raise ValueError('โหมดอากาศไม่ถูกต้อง')
   if k=='bundle_discount' and not 0<=v<=20:raise ValueError('ส่วนลดต้องไม่เกิน 20 บาท')
   if k=='shop_name':v=clean_text(v,60)
   if k=='note':v=clean_text(v,180)
   s[k]=v
  c.execute("UPDATE settings SET data=? WHERE id='main'",(json.dumps(s,ensure_ascii=False),))
 return {'ok':True}

def log_event(d):
 kind=d.get('kind','view')
 if kind not in ('view','add','rec_click','banner','checkout'):return {'ok':True}
 with conn() as c:
  c.execute('INSERT INTO events(created,kind,source,product,mood) VALUES (?,?,?,?,?)',(stamp(),kind,safe_source(d.get('source')),clean_text(d.get('product'),45),d.get('mood') if d.get('mood') in GOOD_MOODS else 'any'))
 return {'ok':True}

def get_session(cookie):
 m=re.search(r'(?:^|;\s*)ks_admin=([^;]+)',cookie or '')
 if not m:return False
 token=m.group(1)
 if '.' not in token:return False
 exp_str,sig=token.split('.',1)
 try: exp=int(exp_str)
 except ValueError: return False
 mac=hmac.new(SESSION_SECRET.encode(),exp_str.encode(),hashlib.sha256).hexdigest()
 return exp>=time.time() and hmac.compare_digest(mac,sig)

def make_session():
 exp=str(int(time.time()+12*3600))
 return exp+'.'+hmac.new(SESSION_SECRET.encode(),exp.encode(),hashlib.sha256).hexdigest()

MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'}
class Handler(BaseHTTPRequestHandler):
 server_version='KuansantiCafe/1.0'
 def reply(self,body,status=200,ctype='application/json; charset=utf-8',headers=None):
  data=json.dumps(body,ensure_ascii=False).encode() if isinstance(body,(dict,list)) else body
  self.send_response(status)
  self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(data)))
  self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store')
  self.send_header('X-Frame-Options','SAMEORIGIN')
  if headers:
   for a,b in headers.items(): self.send_header(a,b)
  self.end_headers();self.wfile.write(data)
 def read_json(self):
  ln=int(self.headers.get('Content-Length','0'))
  if ln>80000:raise ValueError('ข้อมูลใหญ่เกินไป')
  try: return json.loads(self.rfile.read(ln).decode('utf-8'))
  except (UnicodeError,json.JSONDecodeError): raise ValueError('JSON ไม่ถูกต้อง')
 def authorized(self): return get_session(self.headers.get('Cookie'))
 def do_GET(self):
  u=urlsplit(self.path); p=u.path
  try:
   if p=='/api/health':return self.reply({'ok':True,'mode':'server','demo_data':DEMO_DATA})
   if p=='/api/public':return self.reply(public_data())
   if p=='/api/owner/snapshot':
    if not self.authorized():return self.reply({'error':'กรุณาเข้าสู่ระบบเจ้าของร้าน'},401)
    return self.reply(owner_snapshot())
   if p=='/api/owner/session':return self.reply({'authenticated':self.authorized()})
   if p=='/qr.png':
    try:
     import qrcode
    except ImportError:
     return self.reply({'error':'ติดตั้ง qrcode ด้วย pip install -r requirements.txt'},500)
    src=safe_source(parse_qs(u.query).get('src',['counter'])[0]); host=self.headers.get('Host','localhost:8000')
    # Host controls QR destination; use only a syntactically reasonable local/public host
    if not re.fullmatch(r'[A-Za-z0-9.\-:\[\]]{1,150}',host):host='localhost:8000'
    proto=self.headers.get('X-Forwarded-Proto','http');proto='https' if proto=='https' else 'http'
    target=f'{proto}://{host}/?src={src}'
    out=io.BytesIO();qrcode.make(target,box_size=10,border=3).save(out,format='PNG')
    return self.reply(out.getvalue(),ctype='image/png')
   if p in ('/','/customer','/index.html'):p='/index.html'
   if p in ('/owner','/owner.html'):p='/owner.html'
   safe=(ROOT/p.lstrip('/')).resolve()
   if not safe.is_relative_to(ROOT) or not safe.is_file() or safe.suffix.lower() not in MIME or (safe.parent!=ROOT and not safe.is_relative_to(ROOT/'assets')):
    return self.reply('Not found'.encode(),404,'text/plain; charset=utf-8')
   return self.reply(safe.read_bytes(),ctype=MIME[safe.suffix.lower()])
  except Exception as e:
   print('GET ERROR:',repr(e),file=sys.stderr);return self.reply({'error':'ระบบขัดข้อง'},500)
 def do_POST(self):
  p=urlsplit(self.path).path
  try:
   d=self.read_json()
   if not isinstance(d,dict):raise ValueError('ต้องส่งข้อมูล JSON')
   if p=='/api/owner/login':
    if hmac.compare_digest(str(d.get('pin','')),OWNER_PIN):
     return self.reply({'ok':True},headers={'Set-Cookie':'ks_admin='+make_session()+'; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200'+('; Secure' if self.headers.get('X-Forwarded-Proto')=='https' else '')})
    return self.reply({'error':'รหัสเจ้าของร้านไม่ถูกต้อง'},401)
   if p=='/api/owner/logout':return self.reply({'ok':True},headers={'Set-Cookie':'ks_admin=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'})
   if p=='/api/order':return self.reply(create_order(d))
   if p=='/api/event':return self.reply(log_event(d))
   if p.startswith('/api/owner/'):
    if not self.authorized():return self.reply({'error':'กรุณาเข้าสู่ระบบเจ้าของร้าน'},401)
    if p=='/api/owner/order':return self.reply(update_order(d))
    if p=='/api/owner/stock':return self.reply(update_stock(d))
    if p=='/api/owner/product':return self.reply(update_product(d))
    if p=='/api/owner/settings':return self.reply(update_settings(d))
   return self.reply({'error':'Not found'},404)
  except ValueError as e:return self.reply({'error':str(e)},400)
  except Exception as e:
   print('POST ERROR:',repr(e),file=sys.stderr);return self.reply({'error':'ระบบขัดข้อง กรุณาลองอีกครั้ง'},500)

def local_ip():
 try:
  s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.connect(('8.8.8.8',80));v=s.getsockname()[0];s.close();return v
 except Exception:return '127.0.0.1'

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--host',default='0.0.0.0');ap.add_argument('--port',type=int,default=8000);args=ap.parse_args()
 init_db()
 print('KUANSANTI SMART CAFÉ is running')
 print(f'Customer: http://localhost:{args.port}/')
 print(f'Owner:    http://localhost:{args.port}/owner')
 print(f'Phone QR: http://{local_ip()}:{args.port}/owner   (same Wi-Fi required)')
 print('Owner demo PIN: ', OWNER_PIN if OWNER_PIN=='2468' else '[configured from environment]')
 if OWNER_PIN=='2468':print('WARNING: default PIN for demonstration ONLY; change OWNER_PIN before sharing.')
 ThreadingHTTPServer((args.host,args.port),Handler).serve_forever()
